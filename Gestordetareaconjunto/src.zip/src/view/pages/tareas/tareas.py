
import flet as ft
from controller.tarea_controller import obtener_tareas, eliminar_tarea
from view.pages.tareas.form_tarea_page import FormTareaPage

class TareasPage(ft.Container):
    def __init__(self):
        super().__init__()
        self.tareas_listview = ft.ListView(expand=True, spacing=10, padding=10)
        self.form_panel = None

    def build(self):
        self.fab = ft.FloatingActionButton(
            icon=ft.icons.ADD,
            bgcolor=ft.colors.DEEP_PURPLE,
            on_click=self.abrir_panel_crear_tarea,
        )

        return ft.Stack([
            ft.Column([
                ft.Text("Tareas", size=30, weight=ft.FontWeight.BOLD),
                self.tareas_listview
            ], expand=True),
            self.fab
        ])

    def did_mount(self):
        self.actualizar_tareas()

    def actualizar_tareas(self):
        tareas = obtener_tareas()
        self.tareas_listview.controls.clear()
        for tarea in tareas:
            tarea_card = self._crear_tarea_card(tarea)
            self.tareas_listview.controls.append(tarea_card)
        self.update()

    def _crear_tarea_card(self, tarea):
        color = ft.colors.YELLOW if not tarea['color'] else tarea['color']
        return ft.Card(
            content=ft.Container(
                bgcolor=ft.colors.WHITE,
                padding=10,
                border_radius=10,
                border=ft.border.all(2, ft.colors.DEEP_PURPLE_ACCENT),
                content=ft.Row([
                    ft.Container(
                        width=20,
                        height=20,
                        bgcolor=color,
                        border_radius=100,
                        border=ft.border.all(1, ft.colors.BLACK38),
                        margin=ft.margin.only(right=12)
                    ),
                    ft.Column([
                        ft.Text(tarea['nombre'], weight=ft.FontWeight.BOLD),
                        ft.Text(tarea['descripcion'] or "Sin descripción")
                    ], expand=True),
                    ft.IconButton(
                        icon=ft.icons.DELETE,
                        icon_color=ft.colors.RED,
                        tooltip="Eliminar",
                        on_click=lambda e, tid=tarea['id']: self.confirmar_eliminar(tid)
                    )
                ])
            )
        )

    def confirmar_eliminar(self, tarea_id):
        def eliminar(e):
            eliminar_tarea(tarea_id)
            self.actualizar_tareas()
            dlg.open = False
            self.update()

        dlg = ft.AlertDialog(
            title=ft.Text("Eliminar Tarea"),
            content=ft.Text("¿Estás seguro de que quieres eliminar esta tarea?"),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: self.cerrar_dialog(dlg)),
                ft.ElevatedButton("Eliminar", on_click=eliminar, bgcolor=ft.colors.RED, color=ft.colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.page.dialog = dlg
        dlg.open = True
        self.update()

    def cerrar_dialog(self, dlg):
        dlg.open = False
        self.update()

    def abrir_panel_crear_tarea(self, e=None):
        self.page.drawer = ft.Drawer(content=FormTareaPage(on_submit=self.on_tarea_creada))
        self.page.drawer.open = True
        self.page.update()

    def on_tarea_creada(self):
        self.page.drawer.open = False
        self.page.update()
        self.actualizar_tareas()
