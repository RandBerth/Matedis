
import flet as ft

def EncargadosPage():
    return ft.Column([
        ft.Text("Encargados Page - contenido aquí"),
    ])
