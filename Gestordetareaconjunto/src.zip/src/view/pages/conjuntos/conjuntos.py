
import flet as ft

def ConjuntosPage():
    return ft.Column([
        ft.Text("Conjuntos Page - contenido aquí"),
    ])
